const { Employee, Criteria, Score, sequelize } = require('../models');

async function initDefaultCriteria() {
  const count = await Criteria.count();
  if (count === 0) {
    await Criteria.bulkCreate([
      { name: 'Produktivitas', weight: 0.4 },
      { name: 'Kehadiran',     weight: 0.3 },
      { name: 'Disiplin',      weight: 0.2 },
      { name: 'Sikap Kerja',   weight: 0.1 }
    ]);
  }
}

// PAGE 1: Landing
exports.showLanding = async (req, res) => {
  res.render('home');
};

// PAGE 2: Form + list karyawan
exports.showEmployeeInputPage = async (req, res) => {
  await initDefaultCriteria();
  const criteria  = await Criteria.findAll();
  const employees = await Employee.findAll();
  res.render('employees/index', { criteria, employees });
};

// Create karyawan + skor per kriteria
exports.createEmployeeWithScores = async (req, res) => {
  const { name, department } = req.body;
  const criteriaKeys = Object.keys(req.body).filter(k => k.startsWith('criteria_'));

  await sequelize.transaction(async (t) => {
    const employee = await Employee.create({ name, department }, { transaction: t });

    for (const key of criteriaKeys) {
      const criteriaId = key.split('_')[1];
      const value = Number(req.body[key]) || 0;

      await Score.create(
        { employeeId: employee.id, criteriaId, value },
        { transaction: t }
      );
    }
  });

  res.redirect('/employees');
};


// PAGE 3: Hasil ranking
exports.showResult = async (req, res) => {
  await initDefaultCriteria();

  const employees = await Employee.findAll({
    include: {
      model: Score,
      include: Criteria
    }
  });

  const result = employees.map(emp => {
    let totalScore = 0;

    console.log('EMP RAW:', JSON.stringify(emp.toJSON(), null, 2));

    (emp.Scores || []).forEach(sc => {
      // PERBAIKAN: pakai sc.Criterion, bukan sc.Criteria
      const crit = sc.Criterion;
      const rawWeight = crit ? crit.weight : null;
      const rawValue  = sc.value;

      const weight = rawWeight != null ? Number(rawWeight) : 0;
      const value  = rawValue  != null ? Number(rawValue)  : 0;

      const partial = weight * value;

      console.log(
        '  criteriaId', sc.criteriaId,
        '| rawWeight', rawWeight, '->', weight,
        '| rawValue', rawValue, '->', value,
        '| partial', partial
      );

      totalScore += partial;
    });

    console.log('EMP', emp.name, 'FINAL totalScore =', totalScore);

    return {
      id: emp.id,
      name: emp.name,
      department: emp.department,
      totalScore
    };
  });

  result.sort((a, b) => b.totalScore - a.totalScore);

  res.render('employees/result', { result });
};

// API detail (optional)
exports.showEmployeeDetail = async (req, res) => {
  const { id } = req.params;
  const employee = await Employee.findByPk(id, {
    include: {
      model: Score,
      include: Criteria
    }
  });

  if (!employee) return res.status(404).send('Employee not found');

  res.json(employee);
};

// Reset data
exports.resetData = async (req, res) => {
  await Score.destroy({ where: {} });
  await Employee.destroy({ where: {} });
  res.redirect('/employees');
};
