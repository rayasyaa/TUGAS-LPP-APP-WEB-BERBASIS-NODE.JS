module.exports = (sequelize, DataTypes) => {
  const Criteria = sequelize.define('Criteria', {
    name: DataTypes.STRING,
    weight: DataTypes.FLOAT
  });

  return Criteria;
};
