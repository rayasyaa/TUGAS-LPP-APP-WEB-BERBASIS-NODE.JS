class Person {
  constructor(name) {
    this.name = name;
  }

  getDisplayName() {
    return this.name;
  }
}

module.exports = (sequelize, DataTypes) => {
  const Employee = sequelize.define('Employee', {
    name: DataTypes.STRING,
    department: DataTypes.STRING
  });

  class EmployeeEntity extends Person {
    constructor(name, department) {
      super(name);
      this.department = department;
    }

    getDescription() {
      return `${this.getDisplayName()} (${this.department})`;
    }
  }

  Employee.EmployeeEntity = EmployeeEntity;

  return Employee;
};
