module.exports = (sequelize, DataTypes) => {
  const Score = sequelize.define('Score', {
    value: DataTypes.FLOAT
  });

  return Score;
};
