const { Sequelize, DataTypes } = require('sequelize');
const path = require('path');

const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: path.join(__dirname, '..', 'database.sqlite')
});

const EmployeeModel = require('./employee')(sequelize, DataTypes);
const CriteriaModel = require('./criteria')(sequelize, DataTypes);
const ScoreModel = require('./score')(sequelize, DataTypes);

EmployeeModel.hasMany(ScoreModel, { foreignKey: 'employeeId' });
ScoreModel.belongsTo(EmployeeModel, { foreignKey: 'employeeId' });

CriteriaModel.hasMany(ScoreModel, { foreignKey: 'criteriaId' });
ScoreModel.belongsTo(CriteriaModel, { foreignKey: 'criteriaId' });

module.exports = {
  sequelize,
  Sequelize,
  Employee: EmployeeModel,
  Criteria: CriteriaModel,
  Score: ScoreModel
};
