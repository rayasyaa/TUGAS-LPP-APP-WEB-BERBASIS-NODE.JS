const express = require('express');
const router = express.Router();
const controller = require('../controllers/employeeController');

// Page 1: landing
router.get('/', controller.showLanding);

// Page 2: input karyawan + nilai
router.get('/employees', controller.showEmployeeInputPage);
router.post('/employees', controller.createEmployeeWithScores);

// Reset data
router.post('/reset', controller.resetData);

// Page 3: hasil ranking
router.get('/result', controller.showResult);

// API detail (optional)
router.get('/employees/:id', controller.showEmployeeDetail);

module.exports = router;
