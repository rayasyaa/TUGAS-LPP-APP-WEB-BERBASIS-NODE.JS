const express = require('express');
const path = require('path');
const app = express();
const { sequelize } = require('./models');
const employeeRoutes = require('./routes/employeeRoutes');

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', employeeRoutes);

const PORT = 3000;

async function startServer() {
  try {
    await sequelize.sync();
    console.log('Database synced');
    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  } catch (err) {
    console.error('Failed to start server', err);
  }
}

startServer();
